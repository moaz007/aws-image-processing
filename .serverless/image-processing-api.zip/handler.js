const AWS = require("aws-sdk");
const sharp = require("sharp");
const s3 = new AWS.S3();

let isColdStart = true; // Track cold start status

module.exports.uploadImage = async (event) => {
  const startTime = Date.now();
  const coldStart = typeof isColdStart === "undefined" ? true : isColdStart;
  isColdStart = false; // Reset cold start for subsequent invocations

  try {
    const { image, fileName } = JSON.parse(event.body);

    if (!image || !fileName) {
      throw new Error("Missing 'image' or 'fileName'");
    }

    const buffer = Buffer.from(image, "base64");
    await s3.putObject({
      Bucket: "my-new-image-uploads-moaz007",
      Key: fileName,
      Body: buffer,
      ContentType: "image/jpeg",
    }).promise();

    const executionTime = Date.now() - startTime;
    console.log(`Execution time (ms): ${executionTime}, Cold start: ${coldStart}`);

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "Image uploaded successfully!",
        coldStart: coldStart,
        executionTime: executionTime, // Corrected: No division by 1000
      }),
    };
  } catch (error) {
    console.error("Error:", error.message);
    return {
      statusCode: 500,
      body: JSON.stringify({
        message: "Failed to upload image",
        error: error.message,
        coldStart: coldStart,
      }),
    };
  }
};

module.exports.processImage = async (event) => {
  const startTime = Date.now();
  const coldStart = typeof isColdStart === "undefined" ? true : isColdStart;
  isColdStart = false; // Reset cold start for subsequent invocations

  try {
    const { bucketName, fileName } = JSON.parse(event.body);

    if (!bucketName || !fileName) {
      throw new Error("Missing 'bucketName' or 'fileName'");
    }

    const imageObject = await s3.getObject({
      Bucket: bucketName,
      Key: fileName,
    }).promise();

    const processedBuffer = await sharp(imageObject.Body)
      .resize(300, 300)
      .toFormat("jpeg")
      .toBuffer();

    const processedKey = `processed-${fileName}`;
    await s3.putObject({
      Bucket: "my-new-image-processed-moaz007",
      Key: processedKey,
      Body: processedBuffer,
      ContentType: "image/jpeg",
    }).promise();

    const executionTime = Date.now() - startTime;
    console.log(`Execution time (ms): ${executionTime}, Cold start: ${coldStart}`);

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "Image processed successfully!",
        processedKey,
        coldStart: coldStart,
        executionTime: executionTime, // Corrected: No division by 1000
      }),
    };
  } catch (error) {
    console.error("Error:", error.message);
    return {
      statusCode: 500,
      body: JSON.stringify({
        message: "Failed to process image",
        error: error.message,
        coldStart: coldStart,
      }),
    };
  }
};


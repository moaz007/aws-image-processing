#!/bin/bash
# image_processing.sh for AWS - Unified Logging (Final Clean Output)
# Usage: ./image_processing.sh <path_to_image>

set -e  # Exit on error

if [ -z "$1" ]; then
  echo "Usage: ./image_processing.sh <path_to_image>"
  exit 1
fi

# Record overall workflow start time (in milliseconds)
workflowStart=$(date +%s%3N)

# Variables
IMAGE_PATH="$1"
FILE_NAME=$(basename "$IMAGE_PATH")  # Extract the file name from the path
UPLOAD_ENDPOINT="https://ws87a160s6.execute-api.us-east-1.amazonaws.com/dev/upload"
PROCESS_ENDPOINT="https://ws87a160s6.execute-api.us-east-1.amazonaws.com/dev/process"
REGION="us-east-1"

# --- Step 1: Invoke the uploadImage function ---
echo "Invoking uploadImage function for $FILE_NAME..."
ENCODED_IMAGE=$(base64 "$IMAGE_PATH" | tr -d '\n')
TMP_FILE=$(mktemp)
cat <<EOF > "$TMP_FILE"
{
  "image": "$ENCODED_IMAGE",
  "fileName": "$FILE_NAME"
}
EOF

UPLOAD_RESPONSE=$(curl -s -X POST "$UPLOAD_ENDPOINT" \
  -H "Content-Type: application/json" \
  --data @"$TMP_FILE")
rm "$TMP_FILE"

UPLOAD_MESSAGE=$(echo "$UPLOAD_RESPONSE" | jq -r '.message')
if [ "$UPLOAD_MESSAGE" != "Image uploaded successfully!" ]; then
  echo "Upload failed. Response: $UPLOAD_RESPONSE"
  exit 1
fi

# Capture upload execution time from the response
UPLOAD_EXEC=$(echo "$UPLOAD_RESPONSE" | jq -r '.executionTime')

echo "Upload successful: $FILE_NAME uploaded via uploadImage function."

# --- Step 2: Trigger the processImage function ---
echo "Triggering image processing for $FILE_NAME..."
PROCESS_RESPONSE=$(curl -s -X POST "$PROCESS_ENDPOINT" \
  -H "Content-Type: application/json" \
  -d "{
    \"bucketName\": \"my-new-image-uploads-moaz007\",
    \"fileName\": \"$FILE_NAME\"
  }")

PROCESS_MESSAGE=$(echo "$PROCESS_RESPONSE" | jq -r '.message')
if [ "$PROCESS_MESSAGE" != "Image processed successfully!" ]; then
  echo "Processing failed. Response: $PROCESS_RESPONSE"
  exit 1
fi

# Capture process execution time and cold start flag
PROCESS_EXEC=$(echo "$PROCESS_RESPONSE" | jq -r '.executionTime')
COLD_START=$(echo "$PROCESS_RESPONSE" | jq -r '.coldStart')

echo "Processing successful: Processed image saved as $(echo "$PROCESS_RESPONSE" | jq -r '.processedKey') in my-new-image-processed-moaz007."
echo "Cold start: $COLD_START"
echo "Function Execution time: ${PROCESS_EXEC}ms"

# --- Step 3: Calculate Total Workflow Execution Time ---
workflowEnd=$(date +%s%3N)
totalWorkflowTime=$(( workflowEnd - workflowStart ))
echo "Entire workflow execution time: ${totalWorkflowTime}ms"
echo "Workflow completed successfully."

# --- Step 4: Push a Unified Log Entry to CloudWatch Logs ---
UNIFIED_LOG_GROUP="UnifiedWorkflowMetrics"
UNIFIED_LOG_STREAM="workflowRuns"

# Ensure the log group exists (ignore errors if it already exists)
aws logs create-log-group --log-group-name "$UNIFIED_LOG_GROUP" --region "$REGION" 2>/dev/null || true
# Ensure the log stream exists (ignore errors if it already exists)
aws logs create-log-stream --log-group-name "$UNIFIED_LOG_GROUP" --log-stream-name "$UNIFIED_LOG_STREAM" --region "$REGION" 2>/dev/null || true

# Fetch the current sequence token for the log stream (if available)
SEQUENCE_TOKEN=$(aws logs describe-log-streams \
  --log-group-name "$UNIFIED_LOG_GROUP" \
  --log-stream-name "$UNIFIED_LOG_STREAM" \
  --region "$REGION" \
  --query 'logStreams[0].uploadSequenceToken' \
  --output text 2>/dev/null)

CURRENT_TIME=$(date +%s%3N)

# Build the unified log entry as a compact JSON string using jq
UNIFIED_LOG=$(jq -n --arg uploadExec "$UPLOAD_EXEC" \
                   --arg processExec "$PROCESS_EXEC" \
                   --arg coldStart "$COLD_START" \
                   --arg totalWorkflowTime "${totalWorkflowTime}ms" \
                   '{uploadExec: $uploadExec, processExec: $processExec, coldStart: $coldStart, totalWorkflowTime: $totalWorkflowTime}')

# Build the log events array as compact JSON using jq
LOG_EVENTS=$(jq -n --arg timestamp "$CURRENT_TIME" --arg message "$UNIFIED_LOG" '[{timestamp: ($timestamp|tonumber), message: $message}]')

# Push the unified log event to CloudWatch, suppressing any output
if [ "$SEQUENCE_TOKEN" = "None" ] || [ -z "$SEQUENCE_TOKEN" ] || [ "$SEQUENCE_TOKEN" = "null" ]; then
  aws logs put-log-events \
    --log-group-name "$UNIFIED_LOG_GROUP" \
    --log-stream-name "$UNIFIED_LOG_STREAM" \
    --region "$REGION" \
    --log-events "$LOG_EVENTS" > /dev/null 2>&1
else
  aws logs put-log-events \
    --log-group-name "$UNIFIED_LOG_GROUP" \
    --log-stream-name "$UNIFIED_LOG_STREAM" \
    --region "$REGION" \
    --log-events "$LOG_EVENTS" \
    --sequence-token "$SEQUENCE_TOKEN" > /dev/null 2>&1
fi

